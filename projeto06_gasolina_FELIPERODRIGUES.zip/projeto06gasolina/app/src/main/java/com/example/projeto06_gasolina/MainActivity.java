package com.example.projeto06_gasolina;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText edtData, edtHodometro, edtLitros, edtPrecoLitro, edtGasolina, edtEtanol;
    private RadioGroup radioCombustivel;
    private TextView txtResultado, txtUltimo;
    private DBHelper db;
    private final SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt", "BR"));

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DBHelper();
        edtData=findViewById(R.id.edtData); edtHodometro=findViewById(R.id.edtHodometro);
        edtLitros=findViewById(R.id.edtLitros); edtPrecoLitro=findViewById(R.id.edtPrecoLitro);
        edtGasolina=findViewById(R.id.edtGasolina); edtEtanol=findViewById(R.id.edtEtanol);
        radioCombustivel=findViewById(R.id.radioCombustivel); txtResultado=findViewById(R.id.txtResultado);
        txtUltimo=findViewById(R.id.txtUltimo);
        edtData.setText(formato.format(new Date()));
        edtData.setOnClickListener(v -> abrirCalendario());
        findViewById(R.id.btnRegistrar).setOnClickListener(v -> registrar());
        findViewById(R.id.btnAnalisar).setOnClickListener(v -> analisar());
        findViewById(R.id.btnComparar).setOnClickListener(v -> comparar());
        findViewById(R.id.btnUltimo).setOnClickListener(v -> mostrarUltimo());
        mostrarUltimo();
    }

    private void abrirCalendario() {
        Calendar c=Calendar.getInstance();
        new DatePickerDialog(this,(view,year,month,day)->{
            Calendar escolhido=Calendar.getInstance(); escolhido.set(year,month,day);
            edtData.setText(formato.format(escolhido.getTime()));
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private double numero(EditText e) {
        String s=e.getText().toString().trim().replace(",", ".");
        if(s.isEmpty()) throw new IllegalArgumentException("Preencha todos os campos numéricos.");
        double n=Double.parseDouble(s);
        if(!Double.isFinite(n)) throw new IllegalArgumentException("Valor inválido.");
        return n;
    }
    private String combustivelSelecionado() {
        int id=radioCombustivel.getCheckedRadioButtonId();
        if(id==-1) throw new IllegalArgumentException("Selecione o tipo de combustível.");
        return ((RadioButton)findViewById(id)).getText().toString();
    }

    private void registrar() {
        try {
            String data=edtData.getText().toString().trim();
            Date parsed=formato.parse(data);
            if(parsed==null || !formato.format(parsed).equals(data)) throw new IllegalArgumentException("Use a data no formato dd/MM/aaaa.");
            double km=numero(edtHodometro), litros=numero(edtLitros), preco=numero(edtPrecoLitro);
            String tipo=combustivelSelecionado();
            if(km<0 || litros<=0 || preco<=0) throw new IllegalArgumentException("Hodômetro deve ser positivo e litros/preço maiores que zero.");
            SQLiteDatabase w=db.getWritableDatabase();
            android.content.ContentValues cv=new android.content.ContentValues();
            cv.put("data",data); cv.put("hodometro",km); cv.put("litros",litros); cv.put("combustivel",tipo); cv.put("preco",preco);
            w.insertOrThrow("abastecimentos",null,cv);
            Toast.makeText(this,"Abastecimento registrado!",Toast.LENGTH_SHORT).show();
            txtResultado.setText("Registro salvo: "+data+" • "+tipo+"\nTotal abastecido: "+moeda(litros*preco));
            mostrarUltimo();
        } catch(Exception e) { erro(e); }
    }

    private void analisar() {
        Cursor c=null;
        try {
            SQLiteDatabase r=db.getReadableDatabase();
            c=r.rawQuery("SELECT data, hodometro, litros, preco, combustivel FROM abastecimentos ORDER BY id DESC LIMIT 2",null);
            if(c.getCount()<2) { txtResultado.setText("Registre pelo menos dois abastecimentos para calcular o intervalo."); return; }
            c.moveToFirst();
            String dataAtual=c.getString(0), combustivelAtual=c.getString(4); double kmAtual=c.getDouble(1), litros=c.getDouble(2), preco=c.getDouble(3);
            c.moveToNext();
            String dataAnterior=c.getString(0); double kmAnterior=c.getDouble(1);
            double distancia=kmAtual-kmAnterior;
            long dias=(formato.parse(dataAtual).getTime()-formato.parse(dataAnterior).getTime())/(24L*60*60*1000);
            if(distancia<=0) throw new IllegalArgumentException("O hodômetro do registro mais recente deve ser maior que o anterior.");
            if(dias<=0) throw new IllegalArgumentException("A data do registro mais recente deve ser posterior à anterior.");
            double consumo=distancia/litros, custo=litros*preco/distancia, kmDia=distancia/(double)dias;
            txtResultado.setText(String.format(Locale.forLanguageTag("pt-BR"),
                    "ANÁLISE DO ÚLTIMO INTERVALO\n%s → %s\nDistância: %.1f km\nConsumo médio: %.2f km/L\nCusto efetivo: %s por km\nMédia diária: %.2f km/dia\nCombustível registrado: %s",
                    dataAnterior,dataAtual,distancia,consumo,moeda(custo),kmDia,combustivelAtual));
        } catch(Exception e) { erro(e); }
        finally { if(c!=null)c.close(); }
    }

    private void comparar() {
        try {
            double gasolina=numero(edtGasolina), etanol=numero(edtEtanol);
            if(gasolina<=0 || etanol<=0) throw new IllegalArgumentException("Informe preços maiores que zero.");
            double proporcao=etanol/gasolina;
            String msg;
            if(proporcao<0.70) msg=String.format(Locale.forLanguageTag("pt-BR"),"Etanol mais vantajoso (%.1f%% do preço da gasolina).",proporcao*100);
            else if(proporcao>0.70) msg=String.format(Locale.forLanguageTag("pt-BR"),"Gasolina mais vantajosa pela regra dos 70%% (etanol = %.1f%% do preço da gasolina).",proporcao*100);
            else msg="Empate pela regra dos 70%.";
            txtResultado.setText("COMPARAÇÃO DE PREÇOS\nGasolina: "+moeda(gasolina)+"/L\nEtanol: "+moeda(etanol)+"/L\n"+msg+"\nObservação: a regra dos 70% é uma estimativa; a eficiência varia conforme o veículo.");
        } catch(Exception e) { erro(e); }
    }

    private void mostrarUltimo() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT data, hodometro, combustivel FROM abastecimentos ORDER BY id DESC LIMIT 1",null);
        if(c.moveToFirst()) txtUltimo.setText("Último registro: "+c.getString(0)+" | "+String.format(Locale.getDefault(),"%.1f km",c.getDouble(1))+" | "+c.getString(2));
        else txtUltimo.setText("Nenhum abastecimento registrado ainda.");
        c.close();
    }
    private String moeda(double v) { return String.format(Locale.forLanguageTag("pt-BR"),"R$ %.2f",v); }
    private void erro(Exception e) { String m=e.getMessage(); Toast.makeText(this,m==null?"Confira os valores informados.":m,Toast.LENGTH_LONG).show(); }
    private class DBHelper extends SQLiteOpenHelper {
        DBHelper(){super(MainActivity.this,"controle_combustivel.db",null,1);}
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE abastecimentos (id INTEGER PRIMARY KEY AUTOINCREMENT, data TEXT NOT NULL, hodometro REAL NOT NULL, litros REAL NOT NULL, combustivel TEXT NOT NULL, preco REAL NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { }
    }
}